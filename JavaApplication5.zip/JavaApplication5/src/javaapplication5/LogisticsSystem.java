import java.io.*;
import java.util.*;

/**
 * Logistics Management System
 * ICT 1011 – Individual Assignment
 * Author: [Your Name]
 * Date: [Date]
 *
 * Description:
 * A simple menu-driven logistics management program that allows
 * city, vehicle, and delivery management with cost and time estimations.
 * Includes file handling and least-cost route finding.
 */

public class LogisticsSystem {

    static final int MAX_CITIES = 30;
    static final int MAX_DELIVERIES = 50;
    static final double FUEL_PRICE = 310.0;

    static Scanner input = new Scanner(System.in);

    // --- City and Distance Data ---
    static String[] cities = new String[MAX_CITIES];
    static int cityCount = 0;
    static int[][] distance = new int[MAX_CITIES][MAX_CITIES];

    // --- Vehicle Information ---
    static String[] vehicleTypes = {"Van", "Truck", "Lorry"};
    static int[] capacity = {1000, 5000, 10000};
    static double[] ratePerKm = {30, 40, 80};
    static double[] avgSpeed = {60, 50, 45};
    static double[] efficiency = {12, 6, 4};

    // --- Delivery Records ---
    static int deliveryCount = 0;
    static String[] fromCity = new String[MAX_DELIVERIES];
    static String[] toCity = new String[MAX_DELIVERIES];
    static double[] totalCost = new double[MAX_DELIVERIES];
    static double[] profit = new double[MAX_DELIVERIES];
    static double[] totalDistance = new double[MAX_DELIVERIES];

    public static void main(String[] args) {
        // Load previous data
        loadCitiesAndDistances();
        loadDeliveries();

        int choice;
        do {
            showMainMenu();
            choice = input.nextInt();
            input.nextLine();

            switch (choice) {
                case 1 -> manageCities();
                case 2 -> manageDistances();
                case 3 -> handleDeliveryRequest();
                case 4 -> showReports();
                case 5 -> findLeastCostRoute();
                case 0 -> {
                    saveCitiesAndDistances();
                    saveDeliveries();
                    System.out.println("All data saved. Exiting...");
                }
                default -> System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 0);
    }

    // ---------------- MENU ---------------- //

    static void showMainMenu() {
        System.out.println("\n===== LOGISTICS MANAGEMENT SYSTEM =====");
        System.out.println("1. Manage Cities");
        System.out.println("2. Manage Distances");
        System.out.println("3. Handle Delivery Request");
        System.out.println("4. Reports");
        System.out.println("5. Find Least-Cost Route");
        System.out.println("0. Save & Exit");
        System.out.print("Enter your choice: ");
    }

    // ---------------- CITY MANAGEMENT ---------------- //

    static void manageCities() {
        int option;
        do {
            System.out.println("\n--- City Management ---");
            System.out.println("1. Add City");
            System.out.println("2. Rename City");
            System.out.println("3. Remove City");
            System.out.println("4. View All Cities");
            System.out.println("0. Back");
            System.out.print("Select: ");
            option = input.nextInt();
            input.nextLine();

            switch (option) {
                case 1 -> addCity();
                case 2 -> renameCity();
                case 3 -> removeCity();
                case 4 -> displayCities();
            }
        } while (option != 0);
    }

    static void addCity() {
        if (cityCount >= MAX_CITIES) {
            System.out.println("City limit reached!");
            return;
        }
        System.out.print("Enter city name: ");
        String name = input.nextLine();
        for (int i = 0; i < cityCount; i++) {
            if (cities[i].equalsIgnoreCase(name)) {
                System.out.println("City already exists!");
                return;
            }
        }
        cities[cityCount++] = name;
        System.out.println("City added successfully!");
    }

    static void renameCity() {
        displayCities();
        System.out.print("Enter city index to rename: ");
        int index = input.nextInt();
        input.nextLine();
        if (index < 0 || index >= cityCount) {
            System.out.println("Invalid city index!");
            return;
        }
        System.out.print("Enter new city name: ");
        cities[index] = input.nextLine();
        System.out.println("City renamed successfully!");
    }

    static void removeCity() {
        displayCities();
        System.out.print("Enter city index to remove: ");
        int index = input.nextInt();
        if (index < 0 || index >= cityCount) {
            System.out.println("Invalid city index!");
            return;
        }
        for (int i = index; i < cityCount - 1; i++) {
            cities[i] = cities[i + 1];
        }
        cityCount--;
        System.out.println("City removed successfully!");
    }

    static void displayCities() {
        System.out.println("\n--- List of Cities ---");
        for (int i = 0; i < cityCount; i++) {
            System.out.println(i + " - " + cities[i]);
        }
    }

    // ---------------- DISTANCE MANAGEMENT ---------------- //

    static void manageDistances() {
        if (cityCount < 2) {
            System.out.println("Add at least 2 cities first.");
            return;
        }
        System.out.println("\n--- Distance Management ---");
        displayCities();
        System.out.print("Enter source city index: ");
        int i = input.nextInt();
        System.out.print("Enter destination city index: ");
        int j = input.nextInt();

        if (i == j) {
            System.out.println("Distance to itself must be 0!");
            distance[i][j] = 0;
            return;
        }

        System.out.print("Enter distance (km): ");
        int d = input.nextInt();
        distance[i][j] = distance[j][i] = d;
        System.out.println("Distance updated successfully!");
    }

    // ---------------- DELIVERY HANDLING ---------------- //

    static void handleDeliveryRequest() {
        if (cityCount < 2) {
            System.out.println("Add cities first!");
            return;
        }
        displayCities();
        System.out.print("From city index: ");
        int from = input.nextInt();
        System.out.print("To city index: ");
        int to = input.nextInt();

        if (from == to) {
            System.out.println("Source and destination cannot be same!");
            return;
        }

        System.out.print("Enter weight (kg): ");
        double weight = input.nextDouble();
        System.out.println("Select Vehicle Type:");
        for (int i = 0; i < vehicleTypes.length; i++) {
            System.out.println((i + 1) + ". " + vehicleTypes[i]);
        }
        int v = input.nextInt() - 1;

        if (weight > capacity[v]) {
            System.out.println("Weight exceeds vehicle capacity!");
            return;
        }

        int dist = distance[from][to];
        if (dist <= 0) {
            System.out.println("Distance not set between selected cities!");
            return;
        }

        calculateAndDisplayCost(from, to, v, dist, weight);
    }

    static void calculateAndDisplayCost(int from, int to, int vehicle, double D, double W) {
        double R = ratePerKm[vehicle];
        double S = avgSpeed[vehicle];
        double E = efficiency[vehicle];

        double baseCost = D * R * (1 + W / 10000);
        double fuelUsed = D / E;
        double fuelCost = fuelUsed * FUEL_PRICE;
        double totalOpCost = baseCost + fuelCost;
        double profitValue = baseCost * 0.25;
        double customerCharge = totalOpCost + profitValue;
        double time = D / S;

        fromCity[deliveryCount] = cities[from];
        toCity[deliveryCount] = cities[to];
        totalCost[deliveryCount] = customerCharge;
        profit[deliveryCount] = profitValue;
        totalDistance[deliveryCount] = D;
        deliveryCount++;

        System.out.println("\n===================================================");
        System.out.println("DELIVERY COST ESTIMATION");
        System.out.println("---------------------------------------------------");
        System.out.println("From: " + cities[from]);
        System.out.println("To: " + cities[to]);
        System.out.println("Distance: " + D + " km");
        System.out.println("Vehicle: " + vehicleTypes[vehicle]);
        System.out.println("Weight: " + W + " kg");
        System.out.println("---------------------------------------------------");
        System.out.printf("Base Cost: %.2f LKR\n", baseCost);
        System.out.printf("Fuel Used: %.2f L\n", fuelUsed);
        System.out.printf("Fuel Cost: %.2f LKR\n", fuelCost);
        System.out.printf("Operational Cost: %.2f LKR\n", totalOpCost);
        System.out.printf("Profit: %.2f LKR\n", profitValue);
        System.out.printf("Customer Charge: %.2f LKR\n", customerCharge);
        System.out.printf("Estimated Time: %.2f hours\n", time);
        System.out.println("===================================================");
    }

    // ---------------- REPORTS ---------------- //

    static void showReports() {
        if (deliveryCount == 0) {
            System.out.println("No deliveries recorded yet.");
            return;
        }
        double totalRevenue = 0, totalProfit = 0, totalDistanceSum = 0;
        for (int i = 0; i < deliveryCount; i++) {
            totalRevenue += totalCost[i];
            totalProfit += profit[i];
            totalDistanceSum += totalDistance[i];
        }

        double avgDistance = totalDistanceSum / deliveryCount;

        System.out.println("\n===== PERFORMANCE REPORT =====");
        System.out.println("Total Deliveries: " + deliveryCount);
        System.out.println("Total Distance Covered: " + totalDistanceSum + " km");
        System.out.printf("Average Distance: %.2f km\n", avgDistance);
        System.out.printf("Total Revenue: %.2f LKR\n", totalRevenue);
        System.out.printf("Total Profit: %.2f LKR\n", totalProfit);
        System.out.println("=====================================");
    }

    // ---------------- LEAST-COST ROUTE FINDER ---------------- //

    static void findLeastCostRoute() {
        if (cityCount < 2) {
            System.out.println("Add more cities first!");
            return;
        }

        displayCities();
        System.out.print("Enter source index: ");
        int src = input.nextInt();
        System.out.print("Enter destination index: ");
        int dest = input.nextInt();

        List<Integer> visited = new ArrayList<>();
        visited.add(src);

        int minDistance = findMinDistance(src, dest, visited, 0, Integer.MAX_VALUE);
        System.out.println("\nLeast possible distance from " + cities[src] + " to " + cities[dest] + " is: " + minDistance + " km");
    }

    static int findMinDistance(int current, int dest, List<Integer> visited, int currentDist, int bestDist) {
        if (current == dest) {
            return Math.min(currentDist, bestDist);
        }

        for (int i = 0; i < cityCount; i++) {
            if (!visited.contains(i) && distance[current][i] > 0) {
                visited.add(i);
                bestDist = findMinDistance(i, dest, visited, currentDist + distance[current][i], bestDist);
                visited.remove(visited.size() - 1);
            }
        }
        return bestDist;
    }

    // ---------------- FILE HANDLING ---------------- //

    static void saveCitiesAndDistances() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("routes.txt"))) {
            writer.println(cityCount);
            for (int i = 0; i < cityCount; i++) writer.println(cities[i]);
            for (int i = 0; i < cityCount; i++) {
                for (int j = 0; j < cityCount; j++) {
                    writer.print(distance[i][j] + " ");
                }
                writer.println();
            }
        } catch (IOException e) {
            System.out.println("Error saving routes: " + e.getMessage());
        }
    }

    static void loadCitiesAndDistances() {
        File file = new File("routes.txt");
        if (!file.exists()) return;

        try (Scanner sc = new Scanner(file)) {
            cityCount = sc.nextInt();
            sc.nextLine();
            for (int i = 0; i < cityCount; i++) {
                cities[i] = sc.nextLine();
            }
            for (int i = 0; i < cityCount; i++) {
                for (int j = 0; j < cityCount; j++) {
                    distance[i][j] = sc.nextInt();
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading routes: " + e.getMessage());
        }
    }

    static void saveDeliveries() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("deliveries.txt"))) {
            writer.println(deliveryCount);
            for (int i = 0; i < deliveryCount; i++) {
                writer.printf("%s,%s,%.2f,%.2f,%.2f\n",
                        fromCity[i], toCity[i], totalCost[i], profit[i], totalDistance[i]);
            }
        } catch (IOException e) {
            System.out.println("Error saving deliveries: " + e.getMessage());
        }
    }

    static void loadDeliveries() {
        File file = new File("deliveries.txt");
        if (!file.exists()) return;

        try (Scanner sc = new Scanner(file)) {
            deliveryCount = sc.nextInt();
            sc.nextLine();
            for (int i = 0; i < deliveryCount; i++) {
                String[] parts = sc.nextLine().split(",");
                fromCity[i] = parts[0];
                toCity[i] = parts[1];
                totalCost[i] = Double.parseDouble(parts[2]);
                profit[i] = Double.parseDouble(parts[3]);
                totalDistance[i] = Double.parseDouble(parts[4]);
            }
        } catch (IOException e) {
            System.out.println("Error loading deliveries: " + e.getMessage());
        }
    }
}
